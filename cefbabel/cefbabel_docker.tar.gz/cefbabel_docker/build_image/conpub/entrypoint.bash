#!/bin/bash

conpubdstart
tail -f 
