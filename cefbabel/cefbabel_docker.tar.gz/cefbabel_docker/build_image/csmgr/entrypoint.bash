#!/bin/bash

csmgrdstart
tail -f 
