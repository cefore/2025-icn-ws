#!/bin/bash

TARGET=(n101 n102 n103)

### start cefbabeld ###
for target in ${TARGET[@]}; 
do (
   docker exec -d $target bash -c "/docker_data/share/bin/start_cefbabeld.sh $target"
)done
