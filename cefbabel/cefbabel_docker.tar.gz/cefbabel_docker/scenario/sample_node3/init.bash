#!/usr/bin/bash

TARGET=(n101 n102 n103)
TNL_A=(n101 n102)
TNL_B=(n102 n103)

CONF_PATH="/usr/local/cefore/cefnetd.conf"

### create tunnel I/F ###
sudo modprobe ip_gre

for ((i=0; i<"${#TNL_A[@]}"; i++)); 
do (
	IF_NAME="tnl_${TNL_A[i]}-${TNL_B[i]}"
	A_NUM=`echo ${TNL_A[i]} |sed -e 's/^[a-zA-Z]//'`
	B_NUM=`echo ${TNL_B[i]} |sed -e 's/^[a-zA-Z]//'`

	docker exec ${TNL_A[i]} bash -c "ip tunnel add ${IF_NAME} mode gre remote 172.20.1.${B_NUM} local 172.20.1.${A_NUM} dev eth0 ttl 225"
	docker exec ${TNL_A[i]} bash -c "ip link set ${IF_NAME} up"
	docker exec ${TNL_A[i]} bash -c "ip link set ${IF_NAME} arp on"
	docker exec ${TNL_A[i]} bash -c "ip addr add 10.0.${i}.${A_NUM}/24 broadcast 10.0.${i}.255 dev ${IF_NAME}"
	docker exec ${TNL_A[i]} bash -c "ip route add 10.0.${i}.${B_NUM}/32 dev ${IF_NAME}"
	docker exec ${TNL_A[i]} bash -c "ip addr add 2001::${i}:${A_NUM}/112 broadcast 2001::${i}:ffff dev ${IF_NAME}"
	docker exec ${TNL_A[i]} bash -c "ip route add 2001::${i}:${B_NUM}/128 dev ${IF_NAME}"
	docker exec ${TNL_A[i]} bash -c "tc qdisc add dev ${IF_NAME} root netem delay 5ms"

	IF_NAME="tnl_${TNL_B[i]}-${TNL_A[i]}"
	docker exec ${TNL_B[i]} bash -c "ip tunnel add ${IF_NAME} mode gre remote 172.20.1.${A_NUM} local 172.20.1.${B_NUM} dev eth0 ttl 225"
	docker exec ${TNL_B[i]} bash -c "ip link set ${IF_NAME} up"
	docker exec ${TNL_B[i]} bash -c "ip link set ${IF_NAME} arp on"
	docker exec ${TNL_B[i]} bash -c "ip addr add 10.0.${i}.${B_NUM}/24 broadcast 10.0.${i}.255 dev ${IF_NAME}"
	docker exec ${TNL_B[i]} bash -c "ip route add 10.0.${i}.${A_NUM}/32 dev ${IF_NAME}"
	docker exec ${TNL_B[i]} bash -c "ip addr add 2001::${i}:${B_NUM}/112 broadcast 2001::${i}:ffff dev ${IF_NAME}"
	docker exec ${TNL_B[i]} bash -c "ip route add 2001::${i}:${A_NUM}/128 dev ${IF_NAME}"
	docker exec ${TNL_B[i]} bash -c "tc qdisc add dev ${IF_NAME} root netem delay 5ms"
) done


### set config ###
for target in ${TARGET[@]}; 
do (
  #docker exec ${target} bash -c "sed -i 's/^#FORWARDING_STRATEGY=[a-zA-Z0-1]*$/FORWARDING_STRATEGY=full_source/' ${CONF_PATH}"
  docker exec ${target} bash -c "sed -i 's/#REGULAR_INTEREST_MAX_LIFETIME=[0-9]*$/REGULAR_INTEREST_MAX_LIFETIME=30/' ${CONF_PATH}"
  docker exec ${target} bash -c "sed -i 's/#SYMBOLIC_INTEREST_MAX_LIFETIME=[0-9]*$/SYMBOLIC_INTEREST_MAX_LIFETIME=30/' ${CONF_PATH}"
  docker exec ${target} bash -c "sed -i 's/#USE_CEFBABEL=0/USE_CEFBABEL=1/' ${CONF_PATH}"
  docker exec ${target} bash -c "sed -i 's/#CEFBABEL_ROUTE=both/CEFBABEL_ROUTE=udp/' ${CONF_PATH}"
  docker exec ${target} bash -c "sed -i 's/#CEF_LOG_LEVEL=[0-9]*$/CEF_LOG_LEVEL=2/' ${CONF_PATH}"
  docker exec ${target} bash -c "sed -i 's/#FIB_SIZE_APP=64*$/FIB_SIZE_APP=1000000/' ${CONF_PATH}"
  docker exec ${target} bash -c "sed -i 's/#FIB_SIZE=1024*$/FIB_SIZE=65535/' ${CONF_PATH}"
) done

### start cefnetd ###
# for target in ${TARGET[@]}; 
# do (
#   docker exec ${target} bash -c "cefnetdstart" > /dev/null &
# )done
sleep 1

