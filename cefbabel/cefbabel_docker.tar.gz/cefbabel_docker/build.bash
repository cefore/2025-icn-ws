#!/usr/bin/env bash

set -e

#for target in base normal cache csmgr conpub; do
for target in base normal conpub; do
    (
        cd .\/build_image\/"$target"
        pwd
        REPOSITORY_NAME="node-$target"
        docker build -t ${REPOSITORY_NAME} .
        if [ $? -ne 0 ]; then
          exit 1;
        fi
    ) || exit 1
done
