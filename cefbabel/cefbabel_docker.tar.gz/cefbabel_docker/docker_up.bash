#!/usr/bin/bash
set -e

DOCKER_COMPOSE="docker-compose.yml"
INIT_FILE="init.bash"

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <scenario directory> "
    exit 1
fi
if [ ! -d ${1} ]; then
    echo "Error: $1 directory doesn't exist."
    exit 1
fi

docker-compose -f ./${1}/${DOCKER_COMPOSE} build
docker-compose -f ./${1}/${DOCKER_COMPOSE} up -d

docker ps -a | sed -E 's/ ( +)/\1|/g' | cut -f 1,2,4,5 -d "|" | sed -E 's/ +$//g'
docker network ls

sleep 1

chmod +x ./${1}/${INIT_FILE}
./${1}/${INIT_FILE}