#!/usr/bin/env bash

DOCKER_COMPOSE="docker-compose.yml"

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <scenario directory> "
    exit 1
fi
if [ ! -d ${1} ]; then
    echo "Error: $1 doesn't exist."
    exit 1
fi

docker-compose -f ./${1}/${DOCKER_COMPOSE} down --remove-orphans --volumes
